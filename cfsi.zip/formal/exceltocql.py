# exceltocql.py
#
# This version gets rid of
# of the sigma to produce the derived
# attributes from an instance with
# only non-derived attributes, opting
# instead to check that excel has
# done it right.

import pycel
# For parsing formulae.

import openpyxl
# For reading cells. Implements a
# tokeniser (lexical analyser) but
# not a parser, which is why I 
# also need Pycel.

import sys
# For resetting stdout after printing
# to a file. I may no longer be
# using it.

import dumper
# For inspecting Pycel's data
# structures when working out how
# to use it. Not needed by the
# rest of the program.

import datetime
# In openpyxl, cell.value can be of
# type datetime.datetime

import os
# For making csv directory

# Data structures
#================

# This program uses a number of data structures.
# Some are defined by Pycel and openpyxl. However,
# I've used as little from them as possible, as 
# the documentation isn't always too good. 
#
# The data structures are, then:
#   * cell names as strings, e.g. 'A1', 'bb237'.
#   * cell ranges as strings, e.g. 'A1:B2', 'bb237:bC238'.
#   Cell names never contain a colon, ranges always do.
#
#   * cell addresses as xy pairs.
#   * cell ranges as top-left/bottom-right pairs.
#   See the creation functions near the end of the
#   program for these. Functions accept these numeric
#   coordinates, or string names, but not both,
#   so be careful!
#
#   * cell contents.
#   These are returned by range_to_asts_etc() in
#   the section on extracting and parsing cells.
#   They depend on what openpyxl does. Integers
#   seem to get returned as integers; formulae,
#   as strings starting with '='; other things, as
#   strings. openpyxl returns the value of blank
#   cells as None, but I generally don't store 
#   these.
#
#   * Pyxel abstract syntax trees.
#   See pycast_to_ast() . They consist
#   of nodes with type OperandNode, OperatorNode,
#   etc. In code, I call them 'pycast'.
#
#   * My abstract syntax trees.
#   Again see pycast_to_ast() . I implement
#   these as dictionaries, for ease of printing
#   etc., and also because I don't know exactly
#   how Pycast AST nodes are meant to behave.
#   In code, I call them 'ast'. See tableref_ast() , 
#   for an example of walking an AST.
#
#   * Lists of cell address/cell contents pairs.
#   See range_to_asts_etc() . This extracts all
#   non-blank cells in a range and returns their
#   addresses and contents in a list. The 'etc'
#   in the function name is because it doesn't
#   only returns ASTs. This is because it can't
#   make them if a cell doesn't contain a formula.
#
#   * Cell coordinates relative to tables.
#   These indicate which table a cell is in,
#   and where. They identify the table name,
#   table column name, and row offset. See
#   tableref_cell() and tableref_ast() .
#
#   * My ASTs augmented with table-relative
#   coordinates. These are like the other ASTs,
#   but with some fields added to cell and
#   range nodes. See tableref_ast() .
#
#   * Lists of cell address/cell contents pairs
#     whose ASTs have been thus augmented. 
#   See tableref_asts_etc() . THIS IS THE 
#   RESULT STRUCTURE YOU WANT.
#
#   * Table info:
#   I generate a dictionary for each table,
#   giving its name, header location, column
#   names, and body location. See 
#   range_to_table_info() .
#
#   * Dictionary mapping table name to 
#     table info.
#   See table_infos in go() .


# The input spreadsheet
#======================

#which_demo = sys.argv[1] == 'true';

demo_infile = sys.argv[1]; #"Master MASP Excel Workbook with Brandon Olog .xlsx" if which_demo else "MASTER_OLOG_James Hansen - WR_678_IS001_APDCasingPressureTest_v1.9.3.1_v11_6_11_22.xlsx"
#
# Path to Brandon's demo input spreadsheet

quote = '"'
# Or it could be changed to "'" !

cqlfile = sys.argv[2]
uwhfile = sys.argv[3]

demo_worksheet = "OLOG"  #"Brandon Olog" if which_demo else "OLOG "

sourceName = sys.argv[4]

if len(sys.argv) > 5:
  cqlOrUwh = sys.argv[5] # Options are "Cql", "Uwh", and "Both" (default)
else:
  cqlOrUwh = "Both"

# Main program
#=============

def main():
  analyse_spreadsheet( demo_infile )



def analyse_spreadsheet( infile ):
  #print( f"Analysing {infile}." ) 
  wb = openpyxl.load_workbook( infile, data_only = False )
  wb_v = openpyxl.load_workbook( infile, data_only = True )


  #  print( f"Worksheet names: {wb.sheetnames}." )
  #
  # Its workbook, returned by openpyxl.

  sheet = wb[demo_worksheet]
  sheet_v = wb_v[demo_worksheet]

#  ws = sheet
#  print("Worksheet %s include %d tables:" % (ws.title, len(ws._tables)))
#  print(ws.tables)
#  print(ws.tables['Table2'])
#  print(ws._tables)
#  for tbl in ws.tables.values():
#    print(" : " + tbl.displayName)
#    print("   -  name = " + tbl.name)
#    print("   -  type = " + (tbl.tableType if isinstance(tbl.tableType, str) else 'n/a'))
#    print("   - range = " + tbl.ref)
#    print("   - #cols = %d" % len(tbl.tableColumns))
#    for col in tbl.tableColumns:
#      print("     : " + col.name)

  tables = { tbl.tableColumns[0].name:tbl.ref for tbl in sheet.tables.values() }
#  print(tables)
#  print(tables == demo_tables)
#  raise Exception()

  # print( f"Worksheet title: '{sheet.title}'." )
  #
  # The olog worksheet

  # print( "Analysing table information." )
  table_infos = { name:range_to_table_info( name, sheet, sheet_v, range ) 
                  for (name, range) in tables.items() 
                }
  #
  # A dict of dicts giving the header and body coordinates
  # of each table. The keys of the outer dict are the same
  # as in demo_tables .

  # print(table_infos)
  
  #  print( "Parsing formulae." )
  asts_etc_by_table = { name:range_to_asts_etc( sheet, sheet_v, table_info['body'], name, table_infos) 
                        for (name, table_info) in table_infos.items() 
                      }
  #
  # A dict of lists. Each list is the 
  # non-empty cells in one of the tables.

  #  print(asts_etc_by_table)

  #  print( "Analysing formulae." )
  tablereffed_asts_etc_by_table =  { name:tableref_asts_etc( asts_etc, table_infos )  
                                     for (name, asts_etc) in asts_etc_by_table.items() 
                                   }

  #  print (tablereffed_asts_etc_by_table )

  #  print( "Indexing by column and row of tables" )

  table_reffed_asts_etc_by_tablecolrow = index_by_colrow( table_infos, tablereffed_asts_etc_by_table )

  #  print( table_reffed_asts_etc_by_tablecolrow )

  #  print( "Generating schema info." )
  schemaInfo = generateSchemaInfo( table_reffed_asts_etc_by_tablecolrow, wb_v )

  #  print( schemaInfo )

  #  print( "Generating instance info." )
  instanceInfo = generateInstanceInfo( wb_v, table_reffed_asts_etc_by_tablecolrow, schemaInfo['schema_data'] )

  #  print( instanceInfo )

  #  print( "Output CQL" )
  if (cqlOrUwh == "Both"):
    output = outputUWH( schemaInfo, instanceInfo, uwhfile )
    outputCsvs( wb_v, table_reffed_asts_etc_by_tablecolrow, schemaInfo['schema_data'] )
    output = outputCQL( schemaInfo, instanceInfo, cqlfile )
  if (cqlOrUwh == "Uwh"):
    output = outputUWH( schemaInfo, instanceInfo, uwhfile )
    outputCsvs( wb_v, table_reffed_asts_etc_by_tablecolrow, schemaInfo['schema_data'] )
  if (cqlOrUwh == "Cql"):
    output = outputCQL( schemaInfo, instanceInfo, cqlfile )

  
# print( "Listing parsed formulae." )
#  for (name,asts_etc) in tablereffed_asts_etc_by_table.items():
#    print( f"IN TABLE {name}: " )
#    print(asts_etc)
#    list_asts_etc( asts_etc, 'A1' )
#    print()

#  print( "Listing parsed formulae with cell names replaced by in-table references." )
#  for (name,asts_etc) in tablereffed_asts_etc_by_table.items():
#    print( f"IN TABLE {name}: " )
#    print(asts_etc)
#    list_asts_etc( asts_etc, 'table' )
#    print()
#  print( "Finished!" )


# Characterising the tables
#==========================

# Takes a table name (e.g. 'Dept'), a sheet,
# and a cell range as a string. (I've called this
# 'rnge' here to avoid clashing with Python's
# range() function.) Returns a dictionary
# containing information about the table:
# the name; its header coordinates;
# its body coordinates; and the column names.
# These are indexed by keys 'table', 'header',
# 'body', and 'names'. The header and body
# coordinates are numeric ranges as returned
# by cellrange_to_coords() . The column names are
# a list.
#
def range_to_table_info( name, sheet, sheet_v, rnge ):
  coords = cellrange_to_coords( rnge )
  top_left = coords[ 'tl' ]
  bottom_right = coords[ 'br' ]
  header_coords = { 'tl':top_left
                  , 'br':{ 'x':bottom_right['x'], 'y':top_left['y'] } 
                  }
  body_coords =   { 'tl':cc_add_y( top_left, 1 )
                  , 'br':bottom_right
                  }
  header_names = []
  for x in range( top_left[ 'x' ], bottom_right[ 'x' ] + 1 ):
    name_coord = { 'x':x, 'y':top_left['y'] }
    cell = get_cell( sheet, sheet_v, name_coord )
    if cell is None:
      raise Exception( "Column-name cell " + str(name_coord) + " is empty." )
    elif cell[ 'what' ] == 'FML' or cell[ 'what' ] == 'INT':
      raise Exception( "Column-name cell " + str(name_coord) + " is an integer or formula." )
    header_names = header_names + [ cell[ 'conts' ] ]
  result = { 'table': name
           , 'header': header_coords
           , 'names': header_names
           , 'body': body_coords 
           }
  return result


# Analysing ASTs for table references
#====================================

# Iterates tableref_ae() below over the
# formulae within each table.
#
def tableref_asts_etc( asts_etc, table_infos ):
  tablereffed_asts_etc = [ tableref_ae( ae, table_infos ) 
                           for ae in asts_etc 
                         ]
  return tablereffed_asts_etc


# Iterates tableref_cell() over a list
# of cells as returned by range_to_asts_etc() .
# It returns a new list in which all
# formula entries have been augmented
# with two fields. These are 'tref'
# and 'tast'. The first gives the coordinates
# of the cell containing the formula,
# within its table: see tableref_cell() .
# The second returns a new formula: an
# AST where all cell and cell-range nodes
# have been similarly augmented.
#
def tableref_ae( ae, table_infos ):
  result = None
  if ae[ 'what' ] != 'FML':
    result = ae
  elif ('coords' in ae['ast']) and ('external_sheet' in ae['ast']['coords']):
    result = ae.copy()
  else:
    result = ae.copy()
    result[ 'tref' ] = tableref_cell( ae[ 'coords' ], table_infos )
    result[ 'tast' ] = tableref_ast( ae[ 'ast' ], table_infos )
  return result

    
# Returns a dict 
# { 'table':table, 'col':column_name, 'row':row },
# giving the cell's coordinates within its table.
# The column is its column name from the table
# header; the row number is based at 1, and runs
# down from the header.
#
def tableref_cell( coords, table_infos, name=None ):
  result = None
  found = False
  if name:
    if not cell_in_table( coords, table_infos[name]):
      raise Exception( "Cell " + str(coords) + " is not in table " + name )
    found = True
    table_info = table_infos[name]
  else:
    for ( name, table_info ) in table_infos.items():
      if cell_in_table( coords, table_info ):
        found = True
        name = table_info[ 'table' ]
        break
  if not found:
    raise Exception( "Cell " + str(coords) + " is not in any table." )
  
  header = table_info[ 'header' ]
  body = table_info[ 'body' ]
  top_left = body[ 'tl' ]
  row = coords[ 'y' ] - top_left[ 'y' ]  
  column =  coords[ 'x' ] - top_left[ 'x' ] 
  column_name = table_info[ 'names' ][ column ]
  result = { 'table':name, 'col':column_name, 'row':row }
  return result


# Maps over an AST, augmenting all cell
# and cell-range nodes by applying
# tableref_cell() .
#
def tableref_ast( ast, table_infos ):
  result = ast.copy()
  #print(ast);
  if ast[ 'what' ] == 'operator' or ast[ 'what' ] == 'function':
    children = [ tableref_ast(c,table_infos) for c in ast[ 'args'] ]
    result[ 'args' ] = children
  elif ast[ 'what' ] == 'range':
    # This is to be tolerant of specifying a table via the whole table, including the header row.
    try:
      tl = tableref_cell( ast['coords']['tl'], table_infos )
    except Exception as err:
      ast['coords']['tl']['y'] = ast['coords']['tl']['y'] + 1

    try:
      result[ 'tcoords' ] = { 'tl': tableref_cell( ast['coords']['tl'], table_infos )
                              , 'br': tableref_cell( ast['coords']['br'], table_infos )
      }
    except Exception as err:
      print("The following exception occurred when resolving table references in the the ast " + str(ast) + ":\n")
      raise
      
  elif ast[ 'what' ] == 'cell':
    result[ 'tcoords' ] = tableref_cell( ast['coords'], table_infos )
  elif ast[ 'what' ] == 'operand':
    pass
  else:
    raise Exception( 'Unknown node ' + str(ast) + '.' )
  return result


# True if the cell is in the table defined by
# table_info.
#
def cell_in_table( cell_coords, table_info ):
  is_in = cc_in( cell_coords, table_info['body'] )
  return is_in


# Extracting and parsing cells
#=============================

# Takes a sheet and a pair of cell coordinates
# defining a range, and returns a list containing
# parsed formulae, and cell values. The function 
# iterates over the range, examining all cells. It 
# first classfies these into empties, formulae 
# (which start with an '='), integer values, and 
# other values. It parses the formulae into syntax 
# trees as defined by pycast_to_ast() below. It then 
# returns the non-empty cells in a list. Each cell 
# and its contents are represented by a dictionary 
# with the fields 'ref' (cell name in A1 style); 
# 'coords' (numeric coordinates); 'what' ('FML', 
# 'INT', 'FLT', 'DTM', or 'OTH'); 'conts' (the contents string);
# and 'value', the cell value from the spreadsheet
# when opened in data-only mode.
# Formulae cells get an extra field 'ast', the syntax tree.
#
def range_to_asts_etc( sheet, sheet_v, rangecoords, table_name=None, table_infos=None ):
  range = cr_to_range( rangecoords )
  # rangecoords are a pair of numeric coordinates
  # generated by me, so convert back to an
  # alphanumeric range for interfacing with openpyxl.
  asts_etc = []
  for column in sheet[ range ]:
    for cell in column:
      
      fstr = cell.value
      # formula string.
      
      ref = cell.column_letter + str(cell.row)
      # Cell's A1-style address.

      value = sheet_v[ ref ].value
      # Cell value. This is obtained from
      # the sheet opened in data mode.
      
      coords = cellname_to_coords( ref )
      # Cell's XY coordinates.

      if fstr is None:
        newCellInfo = { 'ref':ref, 'coords':coords, 'what':'NIL', 'conts':fstr, 'value':value, 'valuewhat':typecode(value) }
      elif isinstance( fstr, int ):
        newCellInfo = { 'ref':ref, 'coords':coords, 'what':'INT', 'conts':fstr, 'value':value, 'valuewhat':typecode(value) }
      elif isinstance( fstr, float ):
        newCellInfo = { 'ref':ref, 'coords':coords, 'what':'FLT', 'conts':fstr, 'value':value, 'valuewhat':typecode(value) }
      elif isinstance( fstr, datetime.datetime ):
        newCellInfo = { 'ref':ref, 'coords':coords, 'what':'DTM', 'conts':fstr, 'value':value, 'valuewhat':typecode(value) }
      elif fstr[ 0 ] == '=':
        newCellInfo = { 'ref':ref, 'coords':coords, 'what':'FML', 'conts':fstr, 'value':value, 'valuewhat':typecode(value), 'ast':formula_to_ast(fstr) }
      else:
        newCellInfo = { 'ref':ref, 'coords':coords, 'what':'OTH', 'conts':fstr, 'value':value, 'valuewhat':typecode(value) }
      if (table_infos):
        tcoords = tableref_cell( coords, table_infos, table_name)
        newCellInfo[ 'tcoords' ] = tcoords
      asts_etc = asts_etc + [ newCellInfo ]
  return asts_etc

# This function is to get the three-letter
# typecode for a pure value (not a formula).
def typecode( value ):
  if value is None:
    return 'NIL'
  elif isinstance( value, int ):
    return 'INT'
  elif isinstance( value, float ):
    return 'FLT'
  elif isinstance( value, datetime.datetime ):
    return 'DTM'
  else:
    return 'OTH'

# Get a single cell. Using range_to_asts_etc
# is overkill for what I want this for (getting
# column names), but saves time. If the cell
# is empty, the function returns None, otherwise
# a single dictionary of the kind representing
# a cell above.
#
def get_cell( sheet, sheet_v, coords ):
  list = range_to_asts_etc( sheet, sheet_v, {'tl':coords, 'br':coords} ) 
  if list == []:
    return None
  else:
    return list[ 0 ] 


# Converts a formula into a Pycel abstract
# syntax tree. This is essential, but it's
# an intermediate step. I use a simpler
# representation, see next function. To
# distinguish, I call Pycel ASTs 'pycast',
# and my ASTs, 'ast'.
# Note that the formula must start with '=',
# as if it were being typed into Excel.
#
def formula_to_pycast( fstr ):
  pycast = pycel.excelformula.ExcelFormula( fstr ).ast
  return pycast


# Converts a formula into our representation
# of an abstract syntax tree. I've coded these
# as dictionaries, because: it's easier to hack;
# it relies less on the internals of a not
# very documented library; it's easier to
# print when doing diagnostics.
# Note that the formula must start with '=',
# as if it were being typed into Excel.
#
def formula_to_ast( fstr ):
  return pycast_to_ast( formula_to_pycast( fstr ) )


# This recursive function converts a Pycel AST
# to my format of AST. The connectivity is the
# same as for the Pycel tree, but nodes are
# represented more simply, as dictionaries. A
# node contains: a type field 'what'; a name field
# 'name'; for functions and operators, a
# 'children' field; and for cells and ranges,
# a 'coords' field.
#
# The 'what' field is 'operator', 'function',
# 'range', 'cell', or 'operand'. These distinctions
# are made partly by Pycel. If I understand them
# correctly, the distinction between operators
# and functions is the same as in other languages.
# 
# The 'name' field is (I think), the token
# returned by openpyxl's lexical analyser. For
# functions, I had to remove a prefix "_xlfn."
# and an open bracket after the name.
#
# The 'children' field is a list of nodes.
#
# I have divided cell references into 'cell'
# (a single cell) and 'range' (contains a colon).
#
# For cells and ranges, I add a field 'coords'.
# For cells, this is the xy coordinates, based at
# 1, and returned as by the function cellname_to_coords().
# For ranges, it's a pair of these, marking the
# top left and bottom right corners.
#
# Operands are what Pycel calls operands. I know
# integers fall into this class, and presumably
# anything else that isn't one of the above does
# too.
#
def pycast_to_ast( pycast ):
  result = None
  name = pycast.token.value
  if isinstance( pycast, pycel.excelformula.OperatorNode ):
    children = [ pycast_to_ast(c) for c in pycast.children ]
    result = { 'what':'operator', 'name':name, 'args':children }
  elif isinstance( pycast, pycel.excelformula.FunctionNode ):
    children = [ pycast_to_ast(c) for c in pycast.children ]
    name = name.replace( "_xlfn.", "" )
    name = name.replace( "(", "" )
    result = { 'what':'function', 'name':name, 'args':children }
  elif isinstance( pycast, pycel.excelformula.RangeNode ):
    if ":" in name:
      coords = cellrange_to_coords( name )
      result = { 'what':'range', 'name':name, 'coords':coords }
    else:
      coords = cellname_to_coords( name )
      result = { 'what':'cell', 'name':name, 'coords':coords }
  elif isinstance( pycast, pycel.excelformula.OperandNode ):
    result = { 'what':'operand', 'name':name }
  else:
    raise Exception( 'Unknown node ' + str(pycast) + '.' )
  return result


# Listing
#========

# Lists the result of range_to_asts_etc() .
# Each cell is listed in either one or two
# lines. Cells containing formulae are
# listed in two lines, like this:
#   FML D20 = XLOOKUP(C20,$H$3:$H$5,$I$3:$I$5)
#   VAL D20 = 102
# The first line is the formula; the second,
# the cell's value, obtained by opening
# the spreadsheet in data mode.
# Non-formula cells are listed like this for
# integers:
#   INT I5 = 103
# and like this for other values:
#   OTH J3 = CS
#
def list_asts_etc( asts_etc, style ):
  for item in asts_etc:
    lhs = f"{item['what']} {item['ref']}"
    if item['what'] == 'FML':
      # Formula cells.
      if style == 'table':
        rhs = deparse_ast( item['tast'], style ) 
      else:
        rhs = deparse_ast( item['ast'], style ) 
      #print( f"{lhs} = {rhs}" )
     # print( f"VAL {item['ref']} = {item['value']}" )
    else:
      # Non-formula cells.
      rhs = item['conts']
      #print( f"{lhs} = {rhs}" )

# Deparsing ASTs
#===============

# Deparses an AST, returning a formula string.
# The style argument determines how cells that
# have been given table references are displayed:
# see below.
# Note that the function is not yet correct,
# as it doesn't insert brackets where precedence
# requires it.
#
def deparse_ast( ast, style ):
  result = ""
  if ast[ 'what' ] == 'function':
    nchildren = len( ast[ 'args' ] )
    if nchildren == 0:
      bracketed = "()"
    elif nchildren == 1:
      bracketed = "(" + deparse_ast( ast['args'][0], style ) + ")"
    else:
      bracketed = "(" + deparse_ast( ast['args'][0], style ) 
      for c in ast['args'][1:nchildren]:
        bracketed = bracketed + "," + deparse_ast( c, style )
      bracketed = bracketed + ")" 
    result = ast['name'] + bracketed                         
  elif ast[ 'what' ] == 'operator':
    nchildren = len( ast[ 'args' ] )
    if nchildren == 1:
      result = ast['name'] \
             + deparse_ast( ast['args'][0], style ) 
    elif nchildren == 2:
      result = deparse_ast( ast['args'][0], style ) \
             + ast['name'] \
             + deparse_ast( ast['args'][1], style ) 
    else:
      raise Exception( "Operator " + ast['name'] + " doesn't have 1 or 2 arguments, but " + nchildren + "." )
  elif ast[ 'what' ] == 'range':
    result = deparse_range( ast, style )
  elif ast[ 'what' ] == 'cell':
    result = deparse_cell( ast, style )
  elif ast[ 'what' ] == 'operand':
    result = ast[ 'name' ]
  else:
    raise Exception( 'Unknown node ' + str(ast) + '.' )
  return result


# Deparses an AST of type 'range'.
# If the style is 'table' and the AST
# has been given table references, the
# function will return those separated
# by a colon, otherwise it returns cell 
# names separated by a colon.
#
def deparse_range( ast, style ):
  if style == 'table' and 'tcoords' in ast:
    tl = ast['tcoords']['tl']
    br = ast['tcoords']['br']
    result = deparse_tcoords( tl ) + ':' + deparse_tcoords( br )
  else:
    result = ast['name']
  return result


# Deparses an AST of type 'cell'.
# If the style is 'table' and the AST
# has been given a table reference, the
# function will return that as a string,
# otherwise it returns a cell name.
#
def deparse_cell( ast, style ):
  if style == 'table' and 'tcoords' in ast:
    result = deparse_tcoords( ast['tcoords'] )
  else:
    result = ast['name']
  return result


# Returns a table reference of the form
# table[ column, row ].
#
def deparse_tcoords( tcoords ):
  result = tcoords[ 'table' ] + '[' \
         + tcoords[ 'col' ] + ',' \
         + str( tcoords[ 'row' ] ) + ']'
  return result


# Numeric cell-coordinate arithmetic
#===================================

# Adds x to a cell coordinate pair.
#
def cc_add_x( coords, x ):
  result = { 'x': coords['x'] + x
           , 'y': coords['y']
           }
  return result


# Adds y to a cell coordinate pair.
#
def cc_add_y( coords, y ):
  result = { 'x': coords['x'] 
           , 'y': coords['y'] + y
           }
  return result


# Adds x and y to a cell coordinate pair.
#
def cc_add_xy( coords, x, y ):
  result = { 'x': coords['x'] + x 
           , 'y': coords['y'] + y
           }
  return result


# Adds two cell coordinate pairs.
#
def cc_add( coords1, coords2 ):
  result = { 'x': coords1['x'] + coords2['x'] 
           , 'y': coords2['y'] + coords2['y']
           }
  return result


# Tests whether a cell coordinate pair
# is inside a range.
#
def cc_in( coords, rangecoords ):
  tl = rangecoords[ 'tl' ]
  br = rangecoords[ 'br' ]
  x_is_in = coords['x'] >= tl['x'] and coords['x'] <= br['x'] 
  y_is_in = coords['y'] >= tl['y'] and coords['y'] <= br['y']
  result = x_is_in and y_is_in
  return result 


# Converting to and from cell names
#==================================

# Converts a cell name such as 'A1' or 'bb237'
# to XY coordinates in the worksheet, based at 1.
# Thus 'A1' becomes 〈1,1〉, 'B2' becomes 〈2,2〉,
# and 'bb237' becomes 〈54,237〉. Cell letters can
# be in upper or lower case. The result is a
# dictionary with keys 'x' to the column and 'y'
# to the row. Undefined for arguments that are not 
# cell names.
#
# I synonym this to cc() below, as I use it a 
# lot when experimenting.
#
def cellname_to_coords( cellstr ):
  sheet_cell = cellstr.split("!")
  
  if (len(sheet_cell)>2):
    raise Exception(cellstr+" is not a valid cellstring")
  if (len(sheet_cell)==2):
    sheet = sheet_cell[0]
    if sheet[0]=="'" and sheet[-1]=="'":
      sheet = sheet[1:-1]
    cell = sheet_cell[1]
  else: cell = cellstr

  xy = openpyxl.utils.cell.coordinate_from_string( cell )
  col = openpyxl.utils.cell.column_index_from_string( xy[0] )
  # See https://stackoverflow.com/questions/12902621/getting-the-row-and-column-numbers-from-coordinate-value-in-openpyxl .
  row = xy[1]
  if (len(sheet_cell)==2):
    return { 'external_sheet':sheet, 'x':col, 'y':row }
  else:
    return { 'x':col, 'y':row }

def cc( cellstr ):
  return cellname_to_coords( cellstr )


# Converts a cell range name such as 'A1:B2' or
# 'c2:bb237' to coordinates of the top-left
# and bottom-right corners. The result is a dictionary
# 〈 'tl':top-left, 'br':bottom-right 〉. Undefined for arguments
# that are not pairs of cell names separated by
# a colon.
#
# I synonym this to cr() below, as I use it a 
# lot too.
#
def cellrange_to_coords( cellrangestr ):
  cellnames = cellrangestr.split( ":" )
  cellcoords = { 'tl': cellname_to_coords( cellnames[0] )
               , 'br': cellname_to_coords( cellnames[1] )
               }
  return cellcoords

def cr( cellrangestr ):
  return cellrange_to_coords( cellrangestr )


# Converts a cell coordinate pair back to
# an A1-style name. Used if I need to call
# openpyxl on numeric coordinates I've generated,
# as it seems to prefer names.
#
def cc_to_name( coords ):
  column = coords[ 'x' ]
  row = coords[ 'y' ]
  result = openpyxl.utils.get_column_letter( column ) + str( row )
  return result
  # See https://stackoverflow.com/questions/31420817/convert-excel-row-column-indices-to-alphanumeric-cell-reference-in-python-openpy .


# As above, but converts the coordinates
# defining a range back to a colon-separated
# pair of names.
#
def cr_to_range( range ):
  tl = range[ 'tl' ]
  br = range[ 'br' ]
  result = cc_to_name( tl ) + ":" + cc_to_name( br )
  return result


# Generating Schema Info
#==================================
def generateSchemaInfo( data, wb_v ):
  entities = []
  foreign_keys_basic = []
  foreign_keys_derived = []
  attributes_basic = []
  attributes_derived = []
  observation_equations = []
  schema_data = [] # The schema as structured data.

  for (table_name, table_infodata) in data.items():
    entities = entities + [table_name]

    table_info = table_infodata[ 'info' ]
    cells = table_infodata[ 'cells' ]
    for (col_name, col_cells) in cells.items():
      if col_name == None:
        continue
      if col_name == table_name:
        continue # the ID column is not an attribute or foreign key
     # print(table_name + "!" + str(col_name))
      col_type = getColType(col_cells)
      schema_datum = {'col_name': col_name, 'table_name': table_name, 'col_type': getTypeString(col_type)}
      if isDerived(data, table_name, col_name, wb_v):
        schema_datum['derived?'] = True
        if col_type.startswith('FID'):
          foreign_keys_derived = foreign_keys_derived + [(maybeQuote("OTH", col_name)) + " : " + (maybeQuote("OTH", table_name)) + " -> " + quote + str(col_type[4:]) + quote]
          schema_datum['attr?'] = False
        else:
          attributes_derived = attributes_derived + [(maybeQuote("OTH", col_name)) + " : " + (maybeQuote("OTH", table_name)) + " -> " + str(getTypeString(col_type)) ]
          schema_datum['attr?'] = True
        derivation_eqn = getDerivationEqn( data, table_name, col_name, wb_v )
        observation_equations += [ derivation_eqn ]
        derivation_eqn = getDerivationEqn( data, table_name, col_name, wb_v, uhw=True )
        schema_datum['equation'] = derivation_eqn
      else:
        schema_datum['derived?'] = False
#        try:
#          getDerivationEqn( data, table_name, col_name, wb_v )
#        except Exception:
#          pass
#        else:
#          raise Exception("For column " + col_name + " in table " + table_name + ", the derivation equation can be gotten even thought it is not a derived column.")
        
        if col_type.startswith('FID'):
          schema_datum['attr?'] = False
          foreign_keys_basic = foreign_keys_basic + [(maybeQuote("OTH", col_name))  + " : " + (maybeQuote("OTH", table_name)) + " -> " + quote + str(col_type[4:]) + quote]
        else:
          schema_datum['attr?'] = True
          attributes_basic = attributes_basic + [(maybeQuote("OTH", col_name))  + " : " + (maybeQuote("OTH", table_name)) + " -> " + str(getTypeString(col_type)) ]

      schema_data = schema_data + [schema_datum]
    #  print(schema_data)

  return { 'entities': entities, 'foreign_keys_basic':foreign_keys_basic, 'foreign_keys_derived':foreign_keys_derived, 'attributes_basic':attributes_basic, 'attributes_derived':attributes_derived, 'observation_equations':observation_equations, 'schema_data': schema_data }

# Eventually, replace this with something
# which tells from the sheet whether the
# attribute is derived, perhaps by the color
# of the header.
def isDerived(data, table_name, col_name, wb_v):
  
  cell = data[table_name][ 'cells' ][ col_name ][0]

  derived = ('ast' in cell) and (cell[ 'ast' ][ 'what' ] == 'operator' or cell[ 'ast' ][ 'what' ] == 'function')

  return derived

def getDerivationEqn( data, table_name, col_name, wb_v, uhw=False ):
  # The following is a kludge to save programming time.
  # Really we should look at the data structures, but
  # instead we just used the rendered string.  This
  # will cause errors in the event that there is an
  # attribute, foreign key, or value with the same name
  # as an ID in a table, but it is okay for a beta version.

 # print( data[ table_name ][ 'cells' ][ col_name][0] )
  
  renderedFormulae = [ renderFormula(data, cell, wb_v) for cell in data[ table_name ][ 'cells' ][ col_name ] ]

  if len(renderedFormulae)==0:
    raise Exception("Cannot find derived formula in empty table " + table_name)

  genericFormula = replaceIDwithX( data, renderedFormulae[0], table_name, 0)
                                                
  for i in range(1, len(renderedFormulae)):
    isThisTheSame = replaceIDwithX( data, renderedFormulae[i], table_name, i) 
    if genericFormula != isThisTheSame:
      raise Exception("Derived column " + col_name + " in table " + table_name + " is invalid: " + renderedFormulae[0] + " and " + renderedFormulae[i] + " do not obtain from the same universal equation " + genericFormula + " vs " + isThisTheSame)
    
  if uhw:
    return maybeQuote("OTH", col_name) + "(x) = " + genericFormula
  return "forall x:" + maybeQuote("OTH", table_name) + ". " + maybeQuote("OTH", col_name) + "(x) = " + genericFormula

def replaceIDwithX( data, formula, table_name, row ):
  return formula.replace(  data[ table_name ][ 'cells' ][ table_name ][ row ][ 'value' ] , "x" )

def getColType(col_cells):

  attrType = 'NIL'
  for cell in col_cells:
    attrType = getSupType(attrType, getCellType(cell) )
  return attrType

def getCellType(cell):
  if cell[ 'what' ] == 'FML' and cell[ 'ast' ][ 'what' ] == 'cell' and not 'external_sheet' in cell[ 'ast' ][ 'coords' ] and cell[ 'tast' ][ 'tcoords' ][ 'col' ] == cell[ 'tast' ][ 'tcoords' ][ 'table' ]:
    return 'FID:' + cell[ 'tast' ][ 'tcoords' ][ 'table' ]
  return cell[ 'valuewhat' ]
    
# Type poset:
#            OTH
#           /   \
#          DTM  FLT
#          | FID  | (FID:[entity] = foreign ID)
#          |  | INT
#          \  |  /
#            NIL

def getSupType(type1, type2):
  if type1.startswith('FID:'):
    if type2 == type1 or type2 == 'NIL':
      return type1
    else:
      raise Exception("It is not admissible to mix foreign keys and attributes, or foreign keys for multiple entities, in the same column. Type1: " + type1 + "Type2: " + type2)
  elif type1 == 'OTH':
    return 'OTH'
  elif type1 == 'DTM':
    if type2 == 'NIL' or type2 == 'DTM':
      return 'DTM'
    else:
      return 'OTH'
  elif type1 == 'FLT':
    if type2 in ['NIL', 'INT', 'FLT']:
      return 'FLT'
    else:
      return 'OTH'
  elif type1 == 'INT':
    if type2 == 'NIL' or type2 == 'INT':
      return 'INT'
    elif type2 == 'FLT':
      return 'FLT'
    else:
      return 'OTH'
  else:
    return type2

# String Manipulation Functions
#==============================

def getTypeString(type):
  if type == 'NIL': return "String";
  if type == 'DTM': return "String";
  if type == 'FLT': return "Float";
  if type == "INT": return "Float";
  if type == "OTH": return "String";
  if type.startswith('FID:'): return type[4:];
  return "String";

def escapeString(string):
  return string.replace("\"","\\\"");
 # return string.replace("\"","");

# Generating Instance Info
#==================================
def generateInstanceInfo( wb_v, data, schema_data ):
  generators = {}
  equations = []
  derived_equations = []

  for (table_name, table_infodata) in data.items():
    table_info = table_infodata[ 'info' ]
    cells = table_infodata[ 'cells' ]
    curGenerators = [] # generators for current table
    for row in range(bodyHeight(table_info)):
#      print(table_name)
#      print(row)
      cell = cells[ table_name ][ row ] #getTableCell(data, table_name, table_name, row) # col_name = table_name for the first (ID) column of table
      curGenerators = curGenerators + [ cell[ 'value' ] ]
    generators[ table_name ] = curGenerators

    for col_name in table_info[ 'names' ]:
      if col_name == None: continue
      derived = False
      if isDerived(data, table_name, col_name, wb_v ):
        derived = True
      if col_name == table_name: # We already just did this
        continue
      col_data = getColDataFromSchema(schema_data, table_name, col_name)
      typing = ""
      if col_data['attr?']:
        typing = "@" + col_data['col_type']
      for row in range(bodyHeight(table_info)):
        cell = cells[ col_name ][ row ] #getTableCell(data, table_name, table_name, row) # col_name = table_name for the first (ID) column of table
        if cell[ 'value' ] == None:
          continue
        renderedValue = renderValue(data, cell, wb_v )
        if renderedValue != None:
          equation = maybeQuote("OTH", col_name) + "(" + maybeQuote("OTH",generators[ table_name ][ row ]) + ") = " + str(renderedValue) + typing # Need to incorporate the possibility of formulas, to get equations like x.attr = y.attr2
          if derived: derived_equations = derived_equations + [ equation ]
          else: equations = equations + [ equation ]

  return { 'generators':generators, 'equations':equations, 'derived_equations':derived_equations }

def getColDataFromSchema(schema_data, table_name, col_name):
  for datum in schema_data:
    if datum['table_name'] == table_name and datum['col_name'] == col_name:
      return datum
  raise Exception("There is no " + col_name + " column in table " + table_name + " in the schema.")

  attributes_data = attributes_data + [{'col_name': col_name, 'table_name': table_name, 'col_type': getTypeString(col_type), 'derived': False}]

def maybeQuote(what, conts):
#  if conts.startswith("\""): 
 #   raise Exception("Ugh " +str( conts))
  #if what in ['OTH', 'DTM', 'FLT']:
    return quote + escapeString(str(conts)) + quote
  #else:
   # return escapeString(str(conts))

# This function takes a cell in a table and
# outputs an expression of the form
# "[column_name]([ID in same row as cell])"
def getReferenceToCell ( data, cell ):
  table_name = cell[ 'tcoords' ][ 'table' ]
  return maybeQuote("OTH", cell[ 'tcoords' ][ 'col' ]) + "(" + maybeQuote("OTH",data[ table_name ][ 'cells' ][ table_name ][ cell[ 'tcoords' ][ 'row' ] ][ 'value' ]) + ")"
  
def render_tast( data, tast, wb_v ):
  if tast[ 'what' ] == 'cell':
    if 'external_sheet' in tast[ 'coords' ]:
      cell = wb_v[ tast[ 'coords' ][ 'external_sheet' ] ][ tast[ 'name' ] ]
      value = cell[ 'value' ]
      #if isinstance( value, str) or isinstance( value, datetime.datetime ):
      value = quote + value + quote
      return value
    else:
      tcoords = tast[ 'tcoords' ]
      return getReferenceToCell( data, data[ tcoords[ 'table' ] ][ 'cells' ][ tcoords[ 'col' ] ][ tcoords[ 'row' ] ] )
  elif tast[ 'what' ] == 'operand':
    result = maybeQuote("OTH",tast[ 'name' ])
  elif tast[ 'what' ] == 'operator':
    nchildren = len( tast[ 'args' ] )
    if nchildren == 1:
      result = maybeQuote("OTH",tast['name']) + "(" + str(render_tast( data, tast['args'][0], wb_v )) + ")"
    elif nchildren == 2:
      result = "(" + str(render_tast( data, tast['args'][0], wb_v )) \
             + " " + maybeQuote("OTH",tast['name']) + " " \
             + str(render_tast( data, tast['args'][1], wb_v )) + ")"
    else:
      raise Exception( "Operator " + tast['name'] + " doesn't have 1 or 2 arguments, but " + str(nchildren) + "." )
  elif tast[ 'what' ] == 'function':
    if tast[ 'name' ] != 'XLOOKUP' and tast[ 'name' ] != 'LOOKUP':
      bracketed = "(" + ",".join([ render_tast( data, arg, wb_v ) for arg in tast['args'] ]) + ")"
      result = tast['name'] + bracketed
    else:
      value = render_tast( data, tast['args'][0], wb_v )
      entity_range = tast['args'][1]
      verifyRange( entity_range, True, data )

      other_range = tast['args'][2]
      verifyRange( other_range, False, data )

      if other_range[ 'what' ] == 'range':
        attOrFK = other_range[ 'tcoords' ][ 'tl' ][ 'col' ]
      else:
        attOrFK = other_range[ 'tcoords' ][ 'col' ]
      result = maybeQuote("OTH", attOrFK) + "(" + value + ")"

  elif tast[ 'what' ] == 'range':
    raise Exception( "Range " + str(tast) + " given where single cell expected.")
  else:
    raise Exception( 'Unknown node ' + str(tast) + '.' )
  return result

# This function verifies that a range used in an olog xlookup is of the correct form
#
def verifyRange( putativeRange, isID, data):
  if isID:
    ordinal = 'second'
  else:
    ordinal = 'third'
  if putativeRange[ 'what' ] != 'range' and putativeRange[ 'what' ] != 'cell':
    raise Exception( "The node " + str(putativeRange) + " should be a range but isn't." )
  if putativeRange[ 'what' ] == 'range' and putativeRange[ 'coords' ][ 'tl' ][ 'x' ] != putativeRange[ 'coords' ][ 'br' ][ 'x' ]:
    raise Exception( "The range " + str(putativeRange) + " should be a single column." )
  if isID:
    if (putativeRange[ 'what' ] == 'range' and putativeRange[ 'tcoords' ][ 'tl' ][ 'col' ] != putativeRange[ 'tcoords' ][ 'br' ][ 'table' ]) or (putativeRange[ 'what' ] == 'cell' and putativeRange[ 'tcoords' ][ 'col' ] != putativeRange[ 'tcoords' ][ 'table' ]):
      raise Exception( "The range " + str(putativeRange) + " taken as the " + ordinal + " argument of XLOOKUP must be an ID column." )
  if (putativeRange[ 'what' ] == 'range' and (putativeRange[ 'tcoords' ][ 'tl' ][ 'table' ] != putativeRange[ 'tcoords' ][ 'br' ][ 'table' ] or putativeRange[ 'coords' ][ 'tl' ][ 'y' ] != data[ putativeRange[ 'tcoords' ][ 'tl' ][ 'table' ] ][ 'info' ][ 'body' ][ 'tl' ][ 'y' ] or putativeRange[ 'coords' ][ 'br' ][ 'y' ] != data[ putativeRange[ 'tcoords' ][ 'br' ][ 'table' ] ][ 'info' ][ 'body' ][ 'br' ][ 'y' ])) or (putativeRange[ 'what' ] == 'cell' and data[ putativeRange[ 'tcoords' ][ 'table' ] ][ 'info' ][ 'body' ][ 'tl' ][ 'y' ] != data[ putativeRange[ 'tcoords' ][ 'table' ] ][ 'info' ][ 'body' ][ 'br' ][ 'y' ]):
    raise Exception( "The range " + str(putativeRange) + " taken as the " + ordinal + " argument of XLOOKUP must be a full column of the body of the table " +  str(data[ putativeRange[ 'tcoords' ][ 'tl' ][ 'table' ] ][ 'info' ][ 'body' ]))


def renderFormula(data, cell, wb_v):
  if cell[ 'what' ] != 'FML':
    return (cell[ 'valuewhat' ], cell[ 'value' ]);
  ast = cell[ 'ast' ]
  if 'coords' in ast and 'external_sheet' in ast[ 'coords' ]:
    external_cell = wb_v[ ast[ 'coords' ][ 'external_sheet' ] ].cell( row=ast[ 'coords' ][ 'y' ], column=ast[ 'coords' ][ 'x' ] )
    value = external_cell.value
    #if isinstance( value, str) or isinstance( value, datetime.datetime ):
    #  value = quote + escapeString(value) + quote
    return maybeQuote("OTH",value);
  tast = cell[ 'tast' ]
  return render_tast(data, tast, wb_v)

def renderValue(data, cell, wb_v):
  return maybeQuote(cell[ 'valuewhat' ], cell[ 'value' ]);
    
# Indexing by column and row
#===========================
def index_by_colrow( table_infos, data ):
  output = { name: {'info': table_info, 'cells': { col_name:[ None for i in range(bodyHeight(table_info)) ] for col_name in table_info[ 'names' ] } }
             for (name, table_info) in table_infos.items()
           }
  for (name, table_data) in data.items():
    for cell in table_data:
      col_name = cell[ 'tcoords' ][ 'col' ]
      row = cell[ 'tcoords' ][ 'row' ]
      output[ name ][ 'cells' ][ col_name ][ row ] = cell
      
  return output

def bodyHeight( table_info ):
  return table_info[ 'body' ][ 'br' ][ 'y' ] - table_info[ 'body' ][ 'tl' ][ 'y' ] + 1

# Formatting CQL
#==================
def outputUWH( schemaInfo, instanceInfo, outfile ):
  output = '''udfs = @ using System;
          using PeterO.Numbers;
	public class Udfs
	{
		public EDecimal Sum(EDecimal a, EDecimal b)
		{
			return (a + b);
		}
		public EDecimal Minus(EDecimal a, EDecimal b)
		{
			return (a - b);
		}
        public EDecimal One()
        {
            return 1;
        }
		public string Append(string a, string b)
		{
			return a + b;
		}
	} @'''
  output += "\n\n\n"
  for entity in schemaInfo[ 'entities' ]:
    output += "source_csv \"" + source(entity) + "\" = \"" + source("Csvs") + "/" + source(entity) + ".csv\"\n"
  output += "\n"

  for entity in schemaInfo[ 'entities' ]:
    output += "rule \"" + source(entity) + "_pk\" = check and enforce primary key \"" + source(entity) + "\"(ID)\n"
  output += "\n"

  for schema_datum in schemaInfo[ 'schema_data' ]:
    if schema_datum[ 'attr?' ] == False:
      output += "rule \"" + source(schema_datum[ 'table_name' ]) + "_" + schema_datum[ 'col_name' ] + "_fk\" = check and enforce\n"
      output += "  foreign key \"" + source(schema_datum[ 'table_name' ]) + "\"(\"" + schema_datum[ 'col_name' ] + "\") references \"" + schema_datum[ 'col_type' ] + "\"(ID)\n"
  output += "\n"

  for schema_datum in schemaInfo[ 'schema_data' ]:
    if schema_datum[ 'derived?' ] == True:
      output += "rule \"" + source(schema_datum[ 'table_name' ]) + "_" + schema_datum[ 'col_name' ] + "_eqn\" = check and enforce\n"
      output += "  forall \"" + source(schema_datum[ 'table_name' ]) + "\" as x implies where " + schema_datum[ 'equation' ] + "\n"

  f = open(outfile, "w")
  f.write(output)
  f.close()
  
  # print (output)
  return output



def outputCsvs( wb_v, data, schema_data ):

  os.mkdir(source("Csvs"))
  for (table_name, table_infodata) in data.items():
    table_info = table_infodata[ 'info' ]
    cells = table_infodata[ 'cells' ]

    cols = table_info[ 'names' ] # names in the table
    colNames = [col.replace("\"", "\"\"") for col in cols ] # names to print in the csv
    colNames[0] = "ID"
    csvString  = "\"" + "\",\"".join(colNames) + "\""

    for row in range(bodyHeight(table_info)):
      rowArray = [ "\"" + str(cells[ col ][ row ][ 'value' ]).replace("\"","\"\"") + "\"" for col in cols ]
      csvString = csvString + "\n" + ",".join(rowArray)
      
    f = open(source("Csvs") + "/" + table_name + ".csv", "w")
    f.write(csvString)
    f.close()

  return
  
def source( name ):
  return sourceName + "_" + name
  
def outputCQL( schemaInfo, instanceInfo, outfile ):
  output = " "
  output += "schema Pre" + sourceName 
  output += " = literal : Ty {\n\tentities\n\t\t"
  output += quote + (quote + " " + quote).join(schemaInfo[ 'entities' ]) + quote
  output += "\n\tforeign_keys\n\t\t"
  output += "\n\t\t".join(schemaInfo[ 'foreign_keys_basic' ])
  output += "\n\tattributes\n\t\t"
  output += "\n\t\t".join(schemaInfo[ 'attributes_basic' ])
  output += "\n}\n\n"
  output += "schema " + sourceName 
  output += " = literal : Ty {\n\timports\n\t\tPre" + sourceName + "\n\t"
  output += "\n\tforeign_keys\n\t\t"
  output += "\n\t\t".join(schemaInfo[ 'foreign_keys_derived' ])
  output += "\n\tattributes\n\t\t"
  output += "\n\t\t".join(schemaInfo[ 'attributes_derived' ])
  output += "\n\tobservation_equations\n\t\t"
  output += "\n\t\t".join(schemaInfo[ 'observation_equations' ])
  output += "\n}\n\n"
#  output += "mapping F" + sourceName + " = include Pre" + sourceName + " " + sourceName + "\n\n"
#  output += "instance I" + sourceName + " = literal : Pre" + sourceName + " {\n\tgenerators\n\t\t"
#  print(instanceInfo[ 'generators' ])
#  output += "\n\t\t".join([ " ".join([ quote+gen+quote for gen in gens]) + " : " + maybeQuote("OTH", col_name) for (col_name, gens) in instanceInfo[ 'generators' ].items() ])
#  output += "\n\tequations\n\t\t"
#  output += "\n\t\t".join(instanceInfo[ 'equations' ])
#  output += "\n}"
#  output += "\n\ninstance " + sourceName + "Instance = sigma F" + sourceName + " " + "I" + sourceName + "\n\n"
  output += "instance " + sourceName + "Instance = literal : " + sourceName + " {\n\tgenerators\n\t\t"
  output += "\n\t\t".join([ " ".join([ quote+gen+quote for gen in gens]) + " : " + maybeQuote("OTH", col_name) for (col_name, gens) in instanceInfo[ 'generators' ].items() ])
  output += "\n\tequations\n\t\t"
  output += "\n\t\t".join(instanceInfo[ 'equations' ]) + "\n\t\t"
  output += "\n\t\t".join(instanceInfo[ 'derived_equations' ])
  output += "\n}"
 # output += "instance K = literal : Target {\n\timports\n\t\tJ"
 # output += "\n\tequations\n\t\t"
 # output += "\n\t\t".join(instanceInfo[ 'derived_equations' ])
 # output += "\n}"
  output += "\nconstraints " + sourceName + "Constraints = literal : " + sourceName + " { }\n"


  f = open(outfile, "w")
  f.write(output)
  f.close()
  # print (output)
  return output

main()
